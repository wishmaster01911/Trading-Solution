# Trading Solutions

A Vite + React + Tailwind starter for a trading dashboard. Includes examples for integrating Finnhub and Alpha Vantage.

## Setup
1. `npm install`
2. Copy `.env.example` to `.env` and set `VITE_FINNHUB_KEY` or `VITE_ALPHAVANTAGE_KEY`.
3. `npm run dev`

## Notes
- The app falls back to mock data when no API key is set.
- Finnhub provides websocket streaming for real-time data — consider switching to websockets for production.


## Serverless proxy (Netlify)

A Netlify Function `proxy` is included in `netlify/functions/proxy.js` which forwards requests to Finnhub or Alpha Vantage using server-side env variables (`FINNHUB_KEY` or `ALPHA_KEY`). Deploy to Netlify and set those env vars in site settings.

## Finnhub websocket

See `src/api/finnhub_ws.js` for a small client example that subscribes to a symbol's real-time trades.

## Testing & CI

- Jest + React Testing Library configured. Run `npm test`.
- A GitHub Actions workflow is included in `.github/workflows/ci.yml` to run tests and build.
