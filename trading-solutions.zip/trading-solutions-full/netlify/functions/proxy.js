// netlify/functions/proxy.js
// Simple proxy that forwards requests to Finnhub or Alpha Vantage using a server-side API key.
// Deploy this as a Netlify Function. Set FINNHUB_KEY or ALPHA_KEY in Netlify env variables.
const fetch = require('node-fetch')

exports.handler = async function(event, context) {
  const params = event.queryStringParameters || {}
  const provider = params.provider || 'finnhub' // 'finnhub' or 'alpha'
  const symbol = params.symbol
  if (!symbol) return { statusCode: 400, body: 'symbol required' }

  try {
    if (provider === 'finnhub') {
      const key = process.env.FINNHUB_KEY
      if (!key) return { statusCode: 500, body: 'Finnhub key not configured' }
      const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${key}`
      const res = await fetch(url)
      const data = await res.json()
      return { statusCode: 200, body: JSON.stringify(data) }
    } else {
      const key = process.env.ALPHA_KEY
      if (!key) return { statusCode: 500, body: 'Alpha key not configured' }
      const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(symbol)}&apikey=${key}`
      const res = await fetch(url)
      const data = await res.json()
      return { statusCode: 200, body: JSON.stringify(data) }
    }
  } catch (err) {
    return { statusCode: 500, body: String(err) }
  }
}
