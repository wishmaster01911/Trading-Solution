// src/api/finnhub_ws.js
// Example of connecting to Finnhub websocket for real-time quotes.
// Usage: import { connectFinnhub } from './api/finnhub_ws'
// call connectFinnhub('AAPL', (msg) => console.log(msg))
export function connectFinnhub(symbol, onData) {
  const key = import.meta.env.VITE_FINNHUB_KEY
  if (!key) throw new Error('VITE_FINNHUB_KEY missing in .env')
  const ws = new WebSocket(`wss://ws.finnhub.io?token=${key}`)
  ws.onopen = () => {
    // subscribe to symbol
    ws.send(JSON.stringify({ type: 'subscribe', symbol }))
  }
  ws.onmessage = (evt) => {
    try {
      const d = JSON.parse(evt.data)
      // message types include trade updates; forward to callback
      onData(d)
    } catch (e) { console.error('ws parse', e) }
  }
  ws.onerror = (e) => console.error('finnhub ws error', e)
  return ws // returns the WebSocket instance so caller can close/unsubscribe
}
