const FINNHUB_KEY = import.meta.env.VITE_FINNHUB_KEY
const ALPHA_KEY = import.meta.env.VITE_ALPHAVANTAGE_KEY

export async function fetchQuoteFinnhub(symbol) {
  if (!FINNHUB_KEY) throw new Error('No Finnhub key provided. Set VITE_FINNHUB_KEY in .env')
  const url = `https://finnhub.io/api/v1/quote?symbol=${encodeURIComponent(symbol)}&token=${FINNHUB_KEY}`
  const res = await fetch(url)
  if (!res.ok) throw new Error('Finnhub fetch failed')
  const data = await res.json()
  return { current: data.c, high: data.h, low: data.l, open: data.o, prevClose: data.pc }
}

export async function fetchDailyApexDataFinnhub(symbol) {
  if (!FINNHUB_KEY) throw new Error('No Finnhub key provided. Set VITE_FINNHUB_KEY in .env')
  const now = Math.floor(Date.now() / 1000)
  const from = now - 60 * 60 * 24 * 30
  const url = `https://finnhub.io/api/v1/stock/candle?symbol=${encodeURIComponent(symbol)}&resolution=D&from=${from}&to=${now}&token=${FINNHUB_KEY}`
  const res = await fetch(url)
  if (!res.ok) throw new Error('Finnhub candles fetch failed')
  const d = await res.json()
  if (d.s !== 'ok') throw new Error('Finnhub returned error state: ' + d.s)
  return d.t.map((ts, i) => ({ x: ts * 1000, y: [d.o[i], d.h[i], d.l[i], d.c[i]] }))
}

export async function fetchQuoteAlpha(symbol) {
  if (!ALPHA_KEY) throw new Error('No Alpha Vantage key provided. Set VITE_ALPHAVANTAGE_KEY in .env')
  const url = `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${encodeURIComponent(symbol)}&apikey=${ALPHA_KEY}`
  const res = await fetch(url)
  if (!res.ok) throw new Error('Alpha fetch failed')
  const json = await res.json()
  const q = json['Global Quote'] || {}
  return {
    current: Number(q['05. price']),
    open: Number(q['02. open']),
    high: Number(q['03. high']),
    low: Number(q['04. low']),
    prevClose: Number(q['08. previous close']),
  }
}

export async function fetchDailyApexDataAlpha(symbol) {
  if (!ALPHA_KEY) throw new Error('No Alpha Vantage key provided. Set VITE_ALPHAVANTAGE_KEY in .env')
  const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=${encodeURIComponent(symbol)}&apikey=${ALPHA_KEY}&outputsize=compact`
  const res = await fetch(url)
  const json = await res.json()
  const ts = json['Time Series (Daily)'] || {}
  const entries = Object.entries(ts).slice(0, 30).reverse()
  return entries.map(([date, v]) => ({ x: new Date(date).getTime(), y: [Number(v['1. open']), Number(v['2. high']), Number(v['3. low']), Number(v['4. close'])] }))
}
