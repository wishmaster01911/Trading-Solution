import React from 'react'

export default function PortfolioTable({ positions }) {
  const totalPL = positions.reduce((s, p) => s + (p.qty * (p.current - p.avg)), 0)
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="font-semibold mb-3">Portfolio</div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-left text-slate-500/90">
            <tr>
              <th>Stock</th>
              <th>Qty</th>
              <th>Invested</th>
              <th>Value</th>
              <th>P&L</th>
              <th>% Change</th>
              <th>Trend</th>
            </tr>
          </thead>
          <tbody>
            {positions.map((p) => (
              <tr key={p.symbol} className="border-t">
                <td className="py-3 font-medium">{p.symbol}</td>
                <td>{p.qty}</td>
                <td>${(p.qty * p.avg).toFixed(2)}</td>
                <td>${(p.qty * p.current).toFixed(2)}</td>
                <td className={`${p.current - p.avg >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>${((p.current - p.avg) * p.qty).toFixed(2)}</td>
                <td>{(((p.current - p.avg) / p.avg) * 100).toFixed(2)}%</td>
                <td>
                  <div className="w-24 h-4 bg-slate-100 rounded-full">
                    <div style={{ width: `${Math.min(100, Math.abs(((p.current - p.avg) / p.avg) * 100))}%` }} className={`${p.current - p.avg >= 0 ? 'bg-emerald-400' : 'bg-rose-400'} h-4 rounded-full`} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-4 text-right font-semibold">Total P&L: <span className={`ml-2 ${totalPL >= 0 ? 'text-emerald-500' : 'text-rose-500'}`}>${totalPL.toFixed(2)}</span></div>
    </div>
  )
}
