import React, { useState } from 'react'

export default function OrderPanel({ onPlaceOrder, activeSymbol, lastPrice }) {
  const [symbol, setSymbol] = useState(activeSymbol || 'AAPL')
  const [qty, setQty] = useState(1)
  const [price, setPrice] = useState('')
  const [type, setType] = useState('Market')
  const [side, setSide] = useState('Buy')

  React.useEffect(() => { setSymbol(activeSymbol) }, [activeSymbol])
  React.useEffect(() => { if (lastPrice) setPrice(lastPrice) }, [lastPrice])

  function place() {
    onPlaceOrder({ symbol, qty: Number(qty), price: type === 'Market' ? lastPrice : Number(price), type, side })
    setQty(1)
  }

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="font-semibold">Place Order</div>
        <div className="text-sm text-slate-500">Last: ${lastPrice}</div>
      </div>
      <div className="space-y-3">
        <div>
          <label className="block text-xs text-slate-500 mb-1">Symbol</label>
          <input value={symbol} onChange={(e) => setSymbol(e.target.value.toUpperCase())} className="w-full border rounded px-3 py-2" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="block text-xs text-slate-500 mb-1">Quantity</label>
            <input value={qty} onChange={(e) => setQty(e.target.value)} type="number" min={1} className="w-full border rounded px-3 py-2" />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">Price</label>
            <input value={price} onChange={(e) => setPrice(e.target.value)} className="w-full border rounded px-3 py-2" />
          </div>
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">Order Type</label>
          <select value={type} onChange={(e) => setType(e.target.value)} className="w-full border rounded px-3 py-2">
            <option>Market</option>
            <option>Limit</option>
          </select>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setSide('Buy')} className={`flex-1 py-2 rounded ${side === 'Buy' ? 'bg-emerald-500 text-white' : 'bg-slate-100'}`}>Buy</button>
          <button onClick={() => setSide('Sell')} className={`flex-1 py-2 rounded ${side === 'Sell' ? 'bg-rose-500 text-white' : 'bg-slate-100'}`}>Sell</button>
        </div>
        <button onClick={place} className="w-full py-2 rounded bg-blue-600 text-white">Place Order</button>
      </div>
    </div>
  )
}
