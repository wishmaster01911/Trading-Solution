import React from 'react'
import { Plus, Home, BarChart2, FileText, ShoppingCart } from 'lucide-react'
import { AreaChart, Area, ResponsiveContainer } from 'recharts'

const mockWatchlist = [
  { symbol: 'AAPL', change: -0.1, spark: [120, 118, 122, 125, 123] },
  { symbol: 'GOOGL', change: -1.05, spark: [145, 142, 140, 141, 139] },
  { symbol: 'TSLA', change: +0.12, spark: [220, 225, 230, 235, 238] },
  { symbol: 'AMZN', change: -0.18, spark: [90, 88, 87, 89, 88] },
]

export default function Sidebar({ active, setActive, collapsed, setCollapsed }) {
  return (
    <aside className={`h-screen ${collapsed ? 'w-20' : 'w-64'} bg-gradient-to-b from-slate-900 to-slate-800 text-white p-4 transition-width duration-300`}>
      <div className="mb-8">
        <div className="text-2xl font-bold">Trading Solutions</div>
      </div>
      <nav className="space-y-3">
        {[
          { key: 'dashboard', label: 'Dashboard', icon: <Home size={18} /> },
          { key: 'charts', label: 'Charts', icon: <BarChart2 size={18} /> },
          { key: 'portfolio', label: 'Portfolio', icon: <FileText size={18} /> },
          { key: 'orders', label: 'Orders', icon: <ShoppingCart size={18} /> },
        ].map((item) => (
          <button key={item.key} onClick={() => setActive(item.key)} className={`w-full flex items-center gap-3 py-2 px-3 rounded-lg hover:bg-white/5 ${active === item.key ? 'bg-white/6 ring-1 ring-blue-400' : ''}`}>
            <div className="opacity-90">{item.icon}</div>
            {!collapsed && <div className="text-sm font-medium">{item.label}</div>}
          </button>
        ))}
      </nav>
      <div className="mt-8">
        <div className="text-xs text-slate-400 mb-2">Watchlist</div>
        <div className="space-y-3">
          {mockWatchlist.map((w) => (
            <div key={w.symbol} className={`p-3 rounded-lg ${w.change >= 0 ? 'bg-emerald-900/10' : 'bg-rose-900/5'}`}>
              <div className="flex justify-between items-center">
                <div className="font-medium">{w.symbol}</div>
                <div className={`text-sm ${w.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>{w.change >= 0 ? '+' : ''}{w.change}%</div>
              </div>
              <div className="h-8 mt-2">
                <ResponsiveContainer width="100%" height={40}>
                  <AreaChart data={w.spark.map((v, i) => ({ value: v, idx: i }))}>
                    <Area dataKey="value" strokeWidth={1} dot={false} strokeOpacity={0.6} fillOpacity={0.05} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="mt-auto">
        <button onClick={() => setCollapsed(!collapsed)} className="mt-6 w-full px-3 py-2 rounded-lg bg-white/6 flex items-center justify-center gap-2">
          <Plus size={14} /> {!collapsed && <span>Collapse</span>}
        </button>
      </div>
    </aside>
  )
}
