import React, { useState, useMemo, useEffect } from 'react'
import Sidebar from './components/Sidebar'
import PortfolioTable from './components/PortfolioTable'
import OrderPanel from './components/OrderPanel'
import Chart from 'react-apexcharts'
import { fetchQuoteFinnhub, fetchDailyApexDataFinnhub, fetchQuoteAlpha, fetchDailyApexDataAlpha } from './api/market'

const mockCandles = [
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 9, y: [105, 110, 100, 108] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 8, y: [108, 116, 106, 115] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 7, y: [115, 120, 110, 118] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 6, y: [118, 125, 115, 122] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 5, y: [122, 130, 120, 128] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 4, y: [128, 135, 125, 132] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 3, y: [132, 137, 129, 134] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 2, y: [134, 136, 130, 131] },
  { x: new Date().getTime() - 1000 * 60 * 60 * 24 * 1, y: [131, 133, 128, 130] },
]

export default function App() {
  const [active, setActive] = useState('dashboard')
  const [collapsed, setCollapsed] = useState(false)
  const [positions, setPositions] = useState([
    { symbol: 'AAPL', qty: 10, avg: 120, current: 130 },
    { symbol: 'TSLA', qty: 5, avg: 210, current: 238 },
  ])
  const [activeSymbol, setActiveSymbol] = useState('AAPL')
  const [candles, setCandles] = useState(mockCandles)
  const [provider, setProvider] = useState('auto') // 'auto', 'finnhub', 'alpha'
  const [lastPrice, setLastPrice] = useState(130)

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        if (provider === 'finnhub') {
          const q = await fetchQuoteFinnhub(activeSymbol)
          const c = await fetchDailyApexDataFinnhub(activeSymbol)
          if (!mounted) return
          setLastPrice(q.current)
          setCandles(c)
        } else if (provider === 'alpha') {
          const q = await fetchQuoteAlpha(activeSymbol)
          const c = await fetchDailyApexDataAlpha(activeSymbol)
          if (!mounted) return
          setLastPrice(q.current)
          setCandles(c)
        } else {
          // try finn hub then alpha, fall back to mock
          try {
            const q = await fetchQuoteFinnhub(activeSymbol)
            const c = await fetchDailyApexDataFinnhub(activeSymbol)
            if (!mounted) return
            setLastPrice(q.current)
            setCandles(c)
          } catch (e) {
            try {
              const q = await fetchQuoteAlpha(activeSymbol)
              const c = await fetchDailyApexDataAlpha(activeSymbol)
              if (!mounted) return
              setLastPrice(q.current)
              setCandles(c)
            } catch (err) {
              // fallback
              setCandles(mockCandles)
            }
          }
        }
      } catch (err) {
        console.error('Live fetch failed', err)
        setCandles(mockCandles)
      }
    }
    load()
    const t = setInterval(load, 15000) // refresh every 15s (rate-limit aware)
    return () => { mounted = false; clearInterval(t) }
  }, [activeSymbol, provider])

  function handlePlaceOrder(order) {
    const { symbol, qty, price, side } = order
    setPositions(prev => {
      const found = prev.find(p => p.symbol === symbol)
      if (found) {
        if (side === 'Buy') {
          const newQty = found.qty + qty
          const newAvg = ((found.avg * found.qty) + price * qty) / newQty
          return prev.map(p => p.symbol === symbol ? { ...p, qty: newQty, avg: newAvg, current: price } : p)
        } else {
          const newQty = Math.max(0, found.qty - qty)
          return prev.map(p => p.symbol === symbol ? { ...p, qty: newQty, current: price } : p)
        }
      } else {
        if (side === 'Buy') {
          return [...prev, { symbol, qty, avg: price, current: price }]
        }
        return prev
      }
    })
  }

  const apexOptions = {
    chart: { type: 'candlestick', height: 350, toolbar: { show: true } },
    title: { text: `${activeSymbol} Chart`, align: 'left' },
    xaxis: { type: 'datetime' },
    yaxis: { tooltip: { enabled: true } },
  }

  const apexSeries = [{ data: candles }]

  return (
    <div className="flex bg-slate-50 min-h-screen">
      <Sidebar active={active} setActive={setActive} collapsed={collapsed} setCollapsed={setCollapsed} />
      <main className="flex-1 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="text-xl font-semibold">Dashboard</div>
          <div className="flex items-center gap-3">
            <select value={provider} onChange={(e) => setProvider(e.target.value)} className="border rounded px-3 py-2">
              <option value="auto">Auto (Finnhub → Alpha → Mock)</option>
              <option value="finnhub">Finnhub</option>
              <option value="alpha">Alpha Vantage</option>
              <option value="mock">Mock</option>
            </select>
            <input placeholder="Symbol" value={activeSymbol} onChange={(e) => setActiveSymbol(e.target.value.toUpperCase())} className="border rounded px-3 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          <div className="col-span-8">
            <div className="mb-4">
              <PortfolioTable positions={positions} />
            </div>
            <div className="bg-white rounded-lg shadow p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="font-semibold">{activeSymbol} Chart</div>
                <div className="flex items-center gap-2">
                  <button className="text-sm px-3 py-1 rounded border">1D</button>
                  <button className="text-sm px-3 py-1 rounded border">1W</button>
                  <button className="text-sm px-3 py-1 rounded border">1M</button>
                </div>
              </div>
              <div style={{ height: 420 }}>
                <Chart options={apexOptions} series={apexSeries} type="candlestick" height={420} />
              </div>
            </div>
          </div>

          <div className="col-span-4 space-y-4">
            <OrderPanel onPlaceOrder={handlePlaceOrder} activeSymbol={activeSymbol} lastPrice={lastPrice} />
            <div className="bg-white rounded-lg shadow p-4">
              <div className="font-semibold mb-3">Orders</div>
              <div className="text-sm text-slate-500">No executed orders in this mock — place orders to see positions update.</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
